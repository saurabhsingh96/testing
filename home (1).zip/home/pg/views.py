from django.shortcuts import render, redirect
from .forms import CustomerForm
from .models import Houses


def home(request):
    data = Houses.objects.filter(isactive='ON')
    state_list = set()
    for d in data:
        state_list.add(d.state)
    context = {"state": state_list}
    return render(request, 'home.html', context)


def about(request):
    data = Houses.objects.filter(isactive='ON')
    state_list = set()
    for d in data:
        state_list.add(d.state)
    context = {"state": state_list}
    return render(request, 'about.html', context)


def pact(request):
    data = Houses.objects.filter(isactive='ON')
    state_list = set()
    for d in data:
        state_list.add(d.state)
    context = {"state": state_list}
    return render(request, 'pact.html', context)


def partner(request):
    data = Houses.objects.filter(isactive='ON')
    state_list = set()
    for d in data:
        state_list.add(d.state)
    context = {"state": state_list}
    return render(request, 'partner.html',context)


def forms(request):
    form = CustomerForm()
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    context = {'form': form}
    return render(request, 'forms.html', context)


def display_data(request, state=None):
    st = set()
    city_list = set()
    ot = set()
    gen = set()
    if state:
        data = Houses.objects.filter(state=state, isactive='ON')

    if request.method == "POST":
        ch1 = request.POST.getlist("choices2")
        ch2 = request.POST.getlist("choices1")
        if len(ch1) > 0:
            data = Houses.objects.filter(isactive='ON', gender__in=ch1)
        if len(ch2) > 0:
            data = Houses.objects.filter(isactive='ON', occupancy_type__in=ch2)
        elif len(ch1) > 0 and len(ch2) > 0:
            data = Houses.objects.filter(isactive='ON', occupancy_type__in=ch2, gender__in=ch1)

    for d in data:
        st.add(d.services_type)
        ot.add(d.occupancy_type)
        gen.add(d.gender)
        city_list.add(d.city)
    context = {"data": data, "state": state, "st": st, "ot": ot, "gen": gen, "tp": city_list, "is_state": "OFF"}
    return render(request, 'display_data.html', context)


def display_city_data(request, state=None, city=None):
    print(city, state)
    st = set()
    city_list = set()
    ot = set()
    gen = set()
    data = Houses.objects.filter(isactive='ON', state=state, city=city)
    if request.method == "POST":
        ch1 = request.POST.getlist("choices2")
        ch2 = request.POST.getlist("choices1")
        if len(ch1) > 0:
            data = Houses.objects.filter(isactive='ON', gender__in=ch1)
        if len(ch2) > 0:
            data = Houses.objects.filter(isactive='ON', occupancy_type__in=ch2)
        elif len(ch1) > 0 and len(ch2) > 0:
            data = Houses.objects.filter(isactive='ON', occupancy_type__in=ch2, gender__in=ch1)

    for d in data:
        st.add(d.services_type)
        ot.add(d.occupancy_type)
        gen.add(d.gender)
        city_list.add(d.city)
    context = {"data": data, "state": state, "st": st, "ot": ot, "gen": gen, "tp": city_list, "is_city": "ON"}
    return render(request, 'display_data.html', context)


def blog(request, slug):
    data = Houses.objects.filter(slug=slug)
    form = CustomerForm()
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')

    context = {"data": data, 'form': form}
    return render(request, 'single_page.html', context)


def houses(request):
    st = set()
    state_list = set()
    ot = set()
    gen = set()
    data = Houses.objects.filter(isactive='ON')
    if request.method == "POST":
        ch1 = request.POST.getlist("choices2")
        ch2 = request.POST.getlist("choices1")
        if len(ch1) > 0:
            data = Houses.objects.filter(isactive='ON', gender__in=ch1)
        if len(ch2) > 0:
            data = Houses.objects.filter(isactive='ON', occupancy_type__in=ch2)
        elif len(ch1) > 0 and len(ch2) > 0:
            data = Houses.objects.filter(isactive='ON', occupancy_type__in=ch2, gender__in=ch1)

    for d in data:
        st.add(d.services_type)
        ot.add(d.occupancy_type)
        gen.add(d.gender)
        state_list.add(d.state)
    context = {"data": data, "st": st, "ot": ot, "gen": gen, "tp": state_list, "is_state": "ON"}
    print(context)
    return render(request, 'display_data.html', context)
