from django.urls import path,re_path
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('', views.home, name="home"),
    path('about/', views.about, name="about"),
    path('pact/', views.pact, name="pact"),
    path('partner/', views.partner, name="partner"),
    path('forms/', views.forms, name='forms'),
    path('houses/<str:state>/', views.display_data, name='display_data'),
    path('houses/<str:state>/<str:city>/', views.display_city_data, name='display_city_data'),
    path('blog/<slug:slug>/', views.blog, name="blog"),
    path('houses/', views.houses, name="houses")
]

urlpatterns += staticfiles_urlpatterns()