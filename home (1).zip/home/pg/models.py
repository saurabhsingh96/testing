from django.db import models
# import uuid
from phonenumber_field.modelfields import PhoneNumberField


class Houses(models.Model):
    # Genders = (('M','Male'), ('F','Female'), ('Both','Both'))
    # property = (('PG','PG & Hostels'),('Apartments','Managed Apartments'))
    # residence = (('Student','Student'),('Working Professional','Working Professional'))
    # occupancy = (('Single','Single'),('Double','Double'),('Triple','Triple'),('Quadruple','Quadruple'),
    #              ('Quintuple','Quintuple'),('Dorm','Dorm'))
    # amenities = (('Attached Balcony','Attached Balcony'),('Attached Washroom','Attached Washroom'),
    #              ('Sliding Window','Sliding Window'))
    # services = (('24x7 Security Surveillance','24x7 Security Surveillance'),('Air Conditioning','Air Conditioning'),
    #             ('High-Speed WIFI','High-Speed WIFI'),('Laundry Service','Laundry Service'))
    # activate = (('ON','ON'),('OFF','OFF'))
    name = models.CharField(max_length=2000)
    state = models.CharField(max_length=2000)
    city = models.CharField(max_length=2000)
    lat = models.DecimalField(max_digits=9, decimal_places=6)
    longi = models.DecimalField(max_digits=9, decimal_places=6)
    gender = models.CharField(max_length=200)
    price = models.IntegerField()
    services_type = models.CharField(max_length=1000)
    Address = models.TextField(blank=True, null=True)
    residence_type = models.CharField(max_length=500)
    occupancy_type = models.CharField(max_length=500)
    amenities_type = models.CharField(max_length=1500)
    isactive = models.CharField(max_length=200)
    img_url1 = models.CharField(max_length=200, null=True)
    img_url2 = models.CharField(max_length=200, null=True)
    img_url3 = models.CharField(max_length=200, null=True)
    img_url4 = models.CharField(max_length=200, null=True)
    slug = models.SlugField(max_length=250, null=True, blank=True)
    # id = models.UUIDField(default=uuid.uuid4, unique=True, primary_key=True, editable=False)
    id = models.AutoField(primary_key=True, auto_created=True)

    def __str__(self):
        return self.name


class Customer(models.Model):
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)
    phone_num = PhoneNumberField(null=False, blank=False, unique=True)
    email = models.EmailField(max_length = 254, null=True)
    city = models.CharField(max_length=200)
    locality = models.CharField(max_length=500)
    duration = models.CharField(max_length=500)

    def __str__(self):
        return self.first_name
