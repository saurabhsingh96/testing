from django.urls import path,re_path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('about/', views.about, name="about"),
    path('pact/', views.pact, name="pact"),
    path('partner/', views.partner, name="partner"),
    path('forms/',views.forms, name='forms'),
    path('display/<str:state>/',views.display_data, name='display_data'),
    path('blog/<slug:slug>/',views.blog, name="blog"),
    path('display_all/',views.display_all, name="display_all")
]