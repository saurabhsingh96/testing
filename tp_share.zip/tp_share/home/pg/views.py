from django.shortcuts import render, redirect
from .forms import CustomerForm
from django.http import HttpResponse
from .models import Houses


def home(request):
    return render(request, 'home.html')


def about(request):
    return render(request, 'about.html')


def pact(request):
    return render(request, 'pact.html')


def partner(request):
    return render(request, 'partner.html')


def forms(request):
    form = CustomerForm()
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    context = {'form':form}
    return render(request, 'forms.html', context)


def display_data(request, state):
    st = []
    tp = []
    ot = []
    gen = []
    data = Houses.objects.filter(state=state, isactive='ON')
    if request.method == "POST":
        tp = request.POST.getlist("choices")
        print("tp---------------",tp)
        data = Houses.objects.filter(state=state, isactive='ON')

    for d in data:
        [st.append(d.services_type) if d.services_type not in st else 0]
        [ot.append(d.occupancy_type) if d.occupancy_type not in ot else 0]
        [gen.append(d.gender) if d.gender not in gen else 0]
    context = {"data":data, "state":state, "st":st, "ot":ot, "gen":gen}
    # print(context)
    return render(request, 'display_data.html',context)


def blog(request,slug):
    data = Houses.objects.filter(slug=slug)

    form = CustomerForm()
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')

    context = {"data":data,'form':form}
    # print(context)
    return render(request,'single_page.html', context)


def display_all(request):
    st = []
    tp = []
    ot = []
    gen = []
    data = Houses.objects.filter(isactive='ON')
    if request.method == "POST":
        tp = request.POST.getlist("choices")
        print("tp.......",tp)
        if len(tp) > 0:
            data = Houses.objects.filter(isactive='ON',gender__in=tp)

    for d in data:
        [st.append(d.services_type) if d.services_type not in st else 0]
        [ot.append(d.occupancy_type) if d.occupancy_type not in ot else 0]
        [gen.append(d.gender) if d.gender not in gen else 0]
    context = {"data": data, "st": st, "ot": ot, "gen": gen}
    # print(context)
    return render(request,'display_data.html',context)