from django.contrib import admin
from .models import Customer,Houses
# Register your models here.
admin.register(Customer)
admin.register(Houses)
